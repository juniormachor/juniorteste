const config = {
        botName: 'Larabot',
        ownerName: 'Lara',
}
