### OPAAA LARA AKI GARAIO ⚡

## Ferramentas

```bash
> Termux
> WhatsApp
> 2 Celulares
```

---


- Get BarBarKey on [this site](https://mhankbarbar.tech)

---

## Instalar
Siga os passos abaixo!

```bash
> termux-setup-storage
(depois disso toque na permissão)
> apt install git
> pkg install ffmpeg
> apt install wget
> pkg install nodejs
> pkg install npm
> git clone chama pv
> cd lara
> bash install.sh
```

## Uso

```bash
> npm start
> leia o códico QR e após isso de um exit
> cd lara
> npm i -g pm2
> pm2 start index.js
> pm2 monit
```


## CONTATOS

- Whatsapp: wa.me//+5581991694245
