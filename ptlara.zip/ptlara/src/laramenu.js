const laramenu = (prefix, pushname) => {
    return `❍ *Comandos do Lara*
    
    ║➩ ❍ ${prefix}setprefix
    ║➩ ❍ ${prefix}block
    ║➩ ❍ ${prefix}tm
    ║➩ ❍ ${prefix}tmctt
    ║➩ ❍ ${prefix}clearall`

}

exports.laramenu = laramenu